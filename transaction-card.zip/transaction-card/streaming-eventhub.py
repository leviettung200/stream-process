# Databricks notebook source
# --- Run 1x to setup the init script. ---
# Restart cluster after running.

# dbutils.fs.put("/databricks/scripts/gdal_install.sh","""
# #!/bin/bash
# curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
# curl https://packages.microsoft.com/config/ubuntu/20.04/prod.list > /etc/apt/sources.list.d/mssql-release.list 
# apt-get update
# ACCEPT_EULA=Y apt-get install msodbcsql17
# apt-get -y install unixodbc-devhttps://packages.microsoft.com
# sudo apt-get install python3-pip -y
# pip3 install --upgrade pyodbc
# """,
# True)

# COMMAND ----------

# display("dbfs:/databricks/scripts/gdal_install.sh")
# with open("/dbfs/databricks/scripts/gdal_install.sh", "r") as f_read:
#   for line in f_read:
#     print(line)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Init Stream

# COMMAND ----------

# Initialize event hub config dictionary with connectionString
ehConf = {}
# ehConf['eventhubs.connectionString'] = "Endpoint=sb://nevtestnamespace.servicebus.windows.net/;SharedAccessKeyName=SASinstance;SharedAccessKey=GIfonT9ap5pTWe+0tUUMOPc258AyrW0yDuhRCKBqbfQ=;EntityPath=nevtestinstance"
connectionString = "Endpoint=sb://nevtestnamespace.servicebus.windows.net/;SharedAccessKeyName=SASinstance;SharedAccessKey=GIfonT9ap5pTWe+0tUUMOPc258AyrW0yDuhRCKBqbfQ=;EntityPath=nevtestinstance"
# Add consumer group to the ehConf dictionary
ehConf['eventhubs.consumerGroup'] = "$Default"
 
# Encrypt ehConf connectionString property
ehConf['eventhubs.connectionString'] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connectionString)
# Read events from the Event Hub
df = spark.readStream.format("eventhubs").options(**ehConf).load()

# Write stream into defined sink
from pyspark.sql.types import *
import  pyspark.sql.functions as F
 
events_schema = StructType([
  StructField("ssn", StringType(), True),
  StructField("cc_num", StringType(), True),
  StructField("first", StringType(), True),
  StructField("last", StringType(), True),
  StructField("gender", StringType(), True),
  StructField("street", StringType(), True),
  StructField("city", StringType(), True),
  StructField("state", StringType(), True),
  StructField("zip", IntegerType(), True),
  StructField("lat", DoubleType(), True),
  StructField("long", DoubleType(), True),
  StructField("city_pop", IntegerType(), True),
  StructField("job", StringType(), True),
  StructField("dob", StringType(), True),
  StructField("acct_num", StringType(), True),
  StructField("profile", StringType(), True),
  StructField("trans_num", StringType(), True),
  StructField("trans_date", StringType(), True),
  StructField("trans_time", StringType(), True),
  StructField("unix_time", IntegerType(), True),
  StructField("category", StringType(), True),
  StructField("amt", DoubleType(), True),
  StructField("is_fraud", IntegerType(), True),
  StructField("merchant", StringType(), True),
  StructField("merch_lat", DoubleType(), True),
  StructField("merch_long", DoubleType(), True)
])
decoded_df = df.select(F.from_json(F.col("body").cast("string"), events_schema).alias("Payload"))
 
cols = ["ssn","cc_num","first","last","gender","street","city","state","zip","lat","long","city_pop","job","dob","acct_num","trans_num","trans_date","trans_time","unix_time","category","amt","is_fraud","merchant","merch_lat","merch_long"]

# Flatten the JSON properties into separate columns
decoded_df = decoded_df.select(decoded_df.Payload.ssn, decoded_df.Payload.cc_num, decoded_df.Payload.first, decoded_df.Payload.last, decoded_df.Payload.gender, decoded_df.Payload.street, decoded_df.Payload.city, decoded_df.Payload.state, decoded_df.Payload.zip, decoded_df.Payload.lat, decoded_df.Payload.long, decoded_df.Payload.city_pop, decoded_df.Payload.job, decoded_df.Payload.dob, decoded_df.Payload.acct_num, decoded_df.Payload.trans_num, decoded_df.Payload.trans_date, decoded_df.Payload.trans_time,  decoded_df.Payload.unix_time, decoded_df.Payload.category, decoded_df.Payload.amt,decoded_df.Payload.is_fraud, decoded_df.Payload.merchant, decoded_df.Payload.merch_lat,decoded_df.Payload.merch_long).toDF(*cols)

display(decoded_df)

# Write stream to Data Lake in JSON file formats
# df_out = df_events.writeStream\
#   .format("json")\
#   .outputMode("append")\
#   .option("checkpointLocation", "abfss://checkpointcontainer@adlstore.dfs.core.windows.net/checkpointapievents")\
#   .start("abfss://api-eventhub@store05.dfs.core.windows.net/writedata")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Settup Writer

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import *
import pyodbc,logging
import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write to SQL DB

# COMMAND ----------

decoded_df = decoded_df.withColumn("lat", round("lat", 2)).withColumn("long", round("long", 2)).withColumn("merch_lat", round("merch_lat", 2)).withColumn("merch_long", round("merch_long", 2))
# query = decoded_df.writeStream.foreach(RowWriter()).option("checkpointLocation", "/mnt/adls/transaction-raw/checkpoint-sql").start()

# COMMAND ----------

import string
import random
N = 10


def process_batch(df, epoch_id):

    conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:testnev.database.windows.net,1433;Database=transactioncard;Uid=tunglv;Pwd=Tung13032000;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cur = conn.cursor()
    
    jdbcHostname = "testnev.database.windows.net"
    jdbcDatabase = "transactioncard"
    jdbcPort = 1433
    jdbcUsername = "tunglv@testnev"
    jdbcPassword = "Tung13032000"
    jdbcUrl = "jdbc:sqlserver://{0}:{1};databaseName={2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
    connectionProperties = {
      "user" : jdbcUsername,
      "password" : jdbcPassword,
      "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    }
    
    customer = df.select("ssn", "first", "last", "cc_num", "gender", "job", "dob","acct_num").dropDuplicates(["ssn"])
    merchant = df.select("merchant", "category", "merch_lat", "merch_long").dropDuplicates(["merchant", "category"])
    address = df.select ("street", "zip", "lat", "long", "state", "city", "city_pop").dropDuplicates(["street","zip"])
    trans = df.select("ssn","cc_num","street","zip","acct_num","trans_num","trans_date","category","amt","is_fraud","merchant").withColumn("trans_date", date_format(col("trans_date"),"yyyyMMdd"))
    
    tempName = ''.join(random.choices(string.ascii_letters + string.digits, k=N))
    
#     =================================================  Create temp table   ======================================================
    tempCustomer = f"""CREATE TABLE ##{tempName}Customer (
    cust_id bigint primary key  IDENTITY(0,1),
    ssn nvarchar(50),
    first nvarchar(200), 
    last nvarchar(200), 
    cc_num bigint, 
    acct_num bigint, 
    gender nvarchar(10),
    job nvarchar(200), 
    dob date
    )"""
    cur.execute(tempCustomer)
    
    tempAddress = f"""CREATE TABLE ##{tempName}Address (
    addr_id bigint primary key IDENTITY(0,1),
    street nvarchar(200),
    zip bigint, 
    lat decimal(8,2), 
    long decimal(8,2), 
    city nvarchar(200), 
    state nvarchar(200), 
    city_pop bigint
    )"""
    cur.execute(tempAddress)
    
    tempMerchant = f"""CREATE TABLE ##{tempName}Merchant (
    merch_id bigint primary key IDENTITY(0,1),
    merchant nvarchar(200), 
    category nvarchar(200), 
    merch_lat decimal(8,2), 
    merch_long decimal(8,2)
    )"""
    cur.execute(tempMerchant)
    
    
    tempTrans = f"""CREATE TABLE ##{tempName}Trans (
    trans_num nvarchar(50)  primary key,
    
    ssn nvarchar(50),
    cc_num bigint, 
    acct_num bigint, 
    
    street nvarchar(200),
    zip bigint, 
    
    merchant nvarchar(200), 
    category nvarchar(200),
    
    trans_date nvarchar(20),

    amt decimal(8,2), 
    is_fraud int
    )"""
    cur.execute(tempTrans)
    conn.commit()

    
#     write to temp table
    customer.write.jdbc(url=jdbcUrl, table=f"##{tempName}Customer", mode="append", properties=connectionProperties)
    merchant.write.jdbc(url=jdbcUrl, table=f"##{tempName}Merchant", mode="append", properties=connectionProperties)
    address.write.jdbc(url=jdbcUrl, table=f"##{tempName}Address", mode="append", properties=connectionProperties)
    trans.write.jdbc(url=jdbcUrl, table=f"##{tempName}Trans", mode="append", properties=connectionProperties)

#     customer.write.format("jdbc").option("url", "jdbc:sqlserver://kltn.database.windows.net:1433").option("dbtable", f"##{tempName}Customer").option("user", "tunglv").option("password", "Tung13032000").save()
#  ======================================== Write to real table ===============================================================
#    use temp table write merge to real table
    customerIn = f"""
        MERGE dbo.customers AS T 
        USING ##{tempName}Customer AS U
            ON U.cc_num = T.cc_num and U.acct_num = T.acct_num and U.ssn = T.ssn
        WHEN MATCHED THEN 
            UPDATE SET T.first = U.first, T.last = U.last, T.gender = U.gender,  T.job = U.job, T.dob = U.dob
        WHEN NOT MATCHED THEN 
            INSERT (ssn, first, last, cc_num, gender, job, dob, acct_num) VALUES ( U.ssn, U.first, U.last, U.cc_num, U.gender, U.job, U.dob, acct_num);
        """
    cur.execute(customerIn)
    
    addressIn = f"""
        MERGE dbo.addresses AS T 
        USING ##{tempName}Address AS U 
            ON U.street = T.street and  U.zip = T.zip 
        WHEN MATCHED THEN 
            UPDATE SET T.long = U.long, T.city_pop = U.city_pop,  T.lat = U.lat, T.city = U.city
        WHEN NOT MATCHED THEN 
            INSERT (street, zip, lat, long,  state, city, city_pop) VALUES (U.street, U.zip, U.lat, U.long, U.state, U.city,  U.city_pop);
        """
    cur.execute(addressIn)
      
    merchantIn = f"""
    MERGE dbo.merchants AS T 
    USING ##{tempName}Merchant AS U 
        ON U.merchant = T.merchant and U.category = T.category
    WHEN MATCHED THEN 
            UPDATE SET T.merch_lat = U.merch_lat, T.merch_long = U.merch_long
    WHEN NOT MATCHED THEN 
        INSERT (merchant, category, merch_lat, merch_long) VALUES (U.merchant, U.category, U.merch_lat, U.merch_long);
    """
    cur.execute(merchantIn)
    
#    Write to Trans table real
    transIn = f""" 
      WITH transCTE AS (
        select T.trans_num as trans_id, C.cust_id, A.addr_id, M.merch_id, T.trans_date as date_id, T.amt, T.is_fraud
        from ##{tempName}Trans as T 
        inner join  dbo.Customers  as C
          on T.ssn = C.ssn and T.cc_num = C.cc_num and T.acct_num = C.acct_num
        inner join  dbo.merchants  as M
          on T.merchant = M.merchant and T.category = M.category
        inner join  dbo.addresses  as A
          on T.street = A.street and T.zip = A.zip
        )
      INSERT INTO dbo.transactions  (
        trans_id,
        cust_id,
        addr_id,
        merch_id,
        date_id,
        amt,
        is_fraud
        )  SELECT * FROM transCTE 
        """
#             where trans_id NOT in (SELECT trans_id FROM dbo.transaction )

    cur.execute(transIn)   
    
#     drop temp table global
    dropTempCustomer = f"DROP TABLE IF EXISTS  ##{tempName}Customer "
    dropTempMerchant = f"DROP TABLE IF EXISTS  ##{tempName}Merchant"
    dropTempAddress = f"DROP TABLE IF EXISTS  ##{tempName}Address"
    dropTempTrans = f"DROP TABLE IF EXISTS  ##{tempName}Trans"
    cur.execute(dropTempCustomer)
    cur.execute(dropTempMerchant)
    cur.execute(dropTempAddress)
    cur.execute(dropTempTrans)
    
    conn.commit()
    conn.close()
  
query = decoded_df.writeStream.foreachBatch(process_batch).start()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Write to Data Lake

# COMMAND ----------

# dbutils.fs.mount(
#   source = "wasbs://transaction-raw@kltndatalakeg2.blob.core.windows.net",
#   mount_point = "/mnt/adls/transaction-raw",
#   extra_configs = {"fs.azure.account.key.kltndatalakeg2.blob.core.windows.net":"x0mYTlu/3uXgeEbMTn+h4RchxfyR6A4h83MCMN62g4lT/v9wR3jNbkeHNXKyVs77oN+fcA48WeBVt627YrctGA=="})

# COMMAND ----------

# Output Dataframe to Delta
df_out = decoded_df.writeStream\
  .format("delta")\
  .outputMode("append")\
  .option("checkpointLocation", "/mnt/adls/transaction-raw/checkpoint-dl")\
  .start("/mnt/adls/transaction-raw/data")


# COMMAND ----------

class RowWriter:
    def open(self, partition_id, epoch_id):
        print("Opened %d, %d" % (partition_id, epoch_id))
        return True
    def process(self, row):
        jdbcHostname = "kltn.database.windows.net"
        jdbcDatabase = "card_transaction"
        jdbcPort = 1433
        jdbcUsername = "tunglv"
        jdbcPassword = "Tung13032000"
        driver= '{ODBC Driver 17 for SQL Server}'
        
        conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:kltn.database.windows.net,1433;Database=card_transaction;Uid=tunglv;Pwd=Tung13032000;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
        cur = conn.cursor()
        
        customerIn = f"""
        MERGE dim_customer AS T 
        USING (VALUES ('{row[0]}','{row[2]}', '{row[3]}',{row[1]}, '{row[4]}', '{row[12]}', '{row[13]}', {row[14]})) AS U (ssn, first, last, cc_num, gender, job, dob,acct_num) ON U.cc_num = T.cc_num and U.acct_num = T.acct_num and U.ssn = T.ssn
        WHEN MATCHED THEN 
            UPDATE SET T.first = U.first, T.last = U.last, T.gender = U.gender,  T.job = U.job, T.dob = U.dob
        WHEN NOT MATCHED THEN 
            INSERT (ssn, first, last, cc_num, gender, job, dob, acct_num) VALUES ( U.ssn, U.first, U.last, U.cc_num, U.gender, U.job, U.dob, acct_num);
        """
        cur.execute(customerIn)
  
        addressIn = f"""
        MERGE dim_address AS T 
        USING (VALUES ('{str(row[5])}', {str(row[8])},{row[9]}, {row[10]}, '{str(row[7])}', '{str(row[6])}', {str(row[11])})) AS U (street, zip, lat, long, state, city, city_pop) ON U.street = T.street and  U.zip = T.zip 
        WHEN MATCHED THEN 
            UPDATE SET T.long = U.long, T.city_pop = U.city_pop,  T.lat = U.lat, T.city = U.city
        WHEN NOT MATCHED THEN 
            INSERT (street, zip, lat, long,  state, city, city_pop) VALUES (U.street, U.zip, U.lat, U.long, U.state, U.city,  U.city_pop);
        """
    
        cur.execute(addressIn)
      
        merchantIn = f"""
        MERGE dim_merchant AS T 
        USING (VALUES ('{row[22]}', '{row[19]}',{row[23]},{row[24]})) AS U (merchant, category, merch_lat, merch_long) ON U.merchant = T.merchant and U.category = T.category and T.merch_lat = U.merch_lat and T.merch_long = U.merch_long
        WHEN NOT MATCHED THEN 
            INSERT (merchant, category, merch_lat, merch_long) VALUES (U.merchant, U.category, U.merch_lat, U.merch_long);
        """
        cur.execute(merchantIn)
        
        column = {'ssn': 0, 'cc_num': 1, 'first': 2, 'last': 3, 'gender': 4, 'street': 5, 'city': 6, 'state': 7, 'zip': 8, 'lat': 9, 'long': 10, 'city_pop': 11, 'job': 12, 'dob': 13, 'acct_num': 14, 'trans_num': 15, 'trans_date': 16, 'trans_time': 17, 'unix_time': 18, 'category': 19, 'amt': 20, 'is_fraud': 21, 'merchant': 22, 'merch_lat': 23, 'merch_long': 24}
        
        date_time = datetime.datetime.fromtimestamp(row[18])
        time_id = date_time.strftime('%Y%m%d%H%M%S')
        
        timeIn = f"""
        MERGE dim_time AS T 
        USING (VALUES ({time_id},{date_time.hour},{date_time.day},'{date_time.month}',{date_time.year})) AS U (time_id, hour, day, month, year) ON U.time_id = T.time_id
        WHEN NOT MATCHED THEN 
            INSERT (time_id, hour, day, month, year) VALUES (U.time_id, U.hour, U.day, U.month, U.year);
        """
        cur.execute(timeIn)

        transIn = f""" 
     insert into fact_transaction 
     select '{row[15]}' as trans_id,c.cust_id, a.addr_id, m.merchant_id, {time_id} as time_id, {row[20]} as amt, {row[21]} as is_fraud
     from ( select cust_id, 'xx' as join_cl from dbo.dim_customer where ssn = '{row[0]}' and cc_num = {row[1]} and acct_num = {row[14]}) c
     join ( select addr_id, 'xx' as join_cl from dbo.dim_address where street= '{row[5]}' and zip = {row[8]}) a
     on  c.join_cl = a.join_cl 
     join (   select merchant_id, 'xx' as join_cl from dbo.dim_merchant where merchant='{row[22]}' and category='{row[19]}' and merch_lat = {row[23]} and merch_long = {row[24]}) m
     on  c.join_cl = m.join_cl  
     where NOT EXISTS (SELECT * FROM fact_transaction t
              WHERE t.trans_id = '{row[15]}');
        """
#         print(transIn)
        logging.info(transIn)
        cur.execute(transIn)
        
        conn.commit()
        conn.close()
        
    def close(self, error):
        print("Closed with error: %s" % str(error))

# query.awaitTermination()

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE customers AS TARGET
# MAGIC USING df AS SOURCE 
# MAGIC ON (TARGET.Keycol = SOURCE.Keycol) 
# MAGIC WHEN MATCHED 
# MAGIC AND 
# MAGIC (
# MAGIC     TARGET.Col1 != SOURCE.Col1 OR TARGET.Col2 != SOURCE.Col2
# MAGIC ) 
# MAGIC THEN 
# MAGIC UPDATE 
# MAGIC SET 
# MAGIC     TARGET.Col1 = SOURCE.Col1
# MAGIC     , TARGET.col2 = SOURCE.Col2 
# MAGIC WHEN NOT MATCHED BY TARGET 
# MAGIC THEN INSERT (keycol,col1,col2) VALUES (SOURCE.KeyCol, SOURCE.Col1, SOURCE.Col2)
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Structured Streaming with Azure EventHub
# MAGIC - **Azure Event Hub** (1st-party supported Azure streaming platform)
# MAGIC - **Apache Kafka** (streaming platform integrated with open source ecosystem, which is also used in Azure HDInsight)
# MAGIC - **Azure Cosmos DB Change Feed** (set ```ChangeFeedCheckpointLocation``` in configuration, which is better for lambda architecture)
# MAGIC 
# MAGIC You can also sink to various destinations for your business needs.    
# MAGIC 
# MAGIC ![Structured Streaming](https://tsmatz.github.io/images/github/databricks/20191114_Structured_Streaming.jpg)
# MAGIC 
# MAGIC [index](https://github.com/tsmatz/azure-databricks-exercise)

# COMMAND ----------

# MAGIC %fs rm -r /FileStore/temp/checkpointLocation

# COMMAND ----------

jdbcHostname = "kltn.database.windows.net"
jdbcDatabase = "card_transaction"
jdbcPort = 1433
jdbcUsername = "tunglv"
jdbcPassword = "Tung13032000"
driver= '{ODBC Driver 17 for SQL Server}'

import pyodbc

# COMMAND ----------

# query = "insert into CITies(CITY_NAME, STATE, CITY_POPULATION) values ('tun1g','1nam',22222)"
query = f"""
        MERGE dim_merchant AS T 
        USING (VALUES ('ddd', 'kjhgfd',543,746)) AS U (merchant, category, merch_lat, merch_long) ON U.merchant = T.merchant and  U.category = T.category
        WHEN MATCHED THEN 
            UPDATE SET T.merch_lat = U.merch_lat, T.merch_long = U.merch_long
        WHEN NOT MATCHED THEN 
            INSERT (merchant, category, merch_lat, merch_long) VALUES (U.merchant, U.category, U.merch_lat, U.merch_long);
        """
jdbcHostname = "kltn.database.windows.net"
jdbcDatabase = "card_transaction"
jdbcPort = 1433
jdbcUsername = "tunglv"
jdbcPassword = "Tung13032000"
driver= '{ODBC Driver 17 for SQL Server}'

#   row.write.jdbc(url=jdbcUrl, table=query,mode = "ignore", properties=connectionProperties)
#   read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties
#     display(row['city_name'])
with pyodbc.connect('DRIVER='+driver+';SERVER=tcp:'+jdbcHostname+';PORT=1433;DATABASE='+jdbcDatabase+';UID='+jdbcUsername+';PWD='+ jdbcPassword) as conn:
    with conn.cursor() as cursor:
        cursor.execute(query)

# COMMAND ----------


key_list = ["ssn","cc_num","first","last","gender","street","city","state","zip","lat","long","city_pop","job","dob","acct_num","trans_num","trans_date","trans_time","unix_time","category","amt","is_fraud","merchant","merch_lat","merch_long"]
value_list =[i for i in range(27)]

dict_from_list = dict(zip(key_list,value_list))
dict_from_list

# COMMAND ----------

# MAGIC %md
# MAGIC We start streaming computation by defining the sink as streaming query named "read_hub".    
# MAGIC ```start()``` function kicks off the streaming and continue to run as background jobs ...

# COMMAND ----------

readInStreamBody.show()

# COMMAND ----------

# MAGIC %sql select payload.event_name, payload.event_time from read_hub

# COMMAND ----------

# MAGIC %md
# MAGIC Add events into EventHub and see the previous query's result again. (See how streaming is displayed in the previous background job.)

# COMMAND ----------

from pyspark.sql import Row

write_schema = StructType([StructField("body", StringType())])
write_row = [Row(body="{\"event_name\":\"Open\",\"event_time\":\"1540601000\"}")]
write_df = spark.createDataFrame(write_row, write_schema)

(write_df
  .write
  .format("eventhubs")
  .options(**conf)
  .save())

# COMMAND ----------

for s in spark.streams.active:
    s.stop()

# COMMAND ----------

# MAGIC %md
# MAGIC After completed, cancel (stop) previous jobs.