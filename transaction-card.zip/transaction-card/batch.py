# Databricks notebook source
# dbutils.fs.mount(
#   source = "wasbs://sample@nevtest96a4.blob.core.windows.net",
#   mount_point = "/mnt/adls/sample",
#   extra_configs = {"fs.azure.account.key.nevtest96a4.blob.core.windows.net":"aHdGCbnKV51gHZXuDw1Is3eXp4EcvFmwGJGJPi+wpVfFJlBrxKxx0N6J5M4x7OfkA1C6p1+df9JHhT09nnzPfg=="})
# dbutils.fs.mount(
#   source = "wasbs://transaction-raw@nevtest96a4.blob.core.windows.net",
#   mount_point = "/mnt/adls/transaction-raw",
#   extra_configs = {"fs.azure.account.key.nevtest96a4.blob.core.windows.net":"aHdGCbnKV51gHZXuDw1Is3eXp4EcvFmwGJGJPi+wpVfFJlBrxKxx0N6J5M4x7OfkA1C6p1+df9JHhT09nnzPfg=="})

# COMMAND ----------

display(dbutils.fs.mounts())
# dbutils.fs.unmount("/mnt/adls/sample")
# dbutils.fs.unmount("/mnt/adls/transaction-raw")

# COMMAND ----------


# Write stream into defined sink
from pyspark.sql.types import *
import  pyspark.sql.functions as F
 
events_schema = StructType([
  StructField("ssn", StringType(), True),
  StructField("cc_num", StringType(), True),
  StructField("first", StringType(), True),
  StructField("last", StringType(), True),
  StructField("gender", StringType(), True),
  StructField("street", StringType(), True),
  StructField("city", StringType(), True),
  StructField("state", StringType(), True),
  StructField("zip", IntegerType(), True),
  StructField("lat", DoubleType(), True),
  StructField("long", DoubleType(), True),
  StructField("city_pop", IntegerType(), True),
  StructField("job", StringType(), True),
  StructField("dob", StringType(), True),
  StructField("acct_num", StringType(), True),
  StructField("profile", StringType(), True),
  StructField("trans_num", StringType(), True),
  StructField("trans_date", StringType(), True),
  StructField("trans_time", StringType(), True),
  StructField("unix_time", IntegerType(), True),
  StructField("category", StringType(), True),
  StructField("amt", DoubleType(), True),
  StructField("is_fraud", IntegerType(), True),
  StructField("merchant", StringType(), True),
  StructField("merch_lat", DoubleType(), True),
  StructField("merch_long", DoubleType(), True)
])
df = spark.read.format("csv") \
  .option("header", "true").option("delimiter", "|") \
  .schema(events_schema) \
  .load("/mnt/adls/sample/*")
df

# COMMAND ----------

display(df)

# COMMAND ----------

# import pyspark.sql.functions as f
# # from pyspark.sql import Window
# w1 = Window.partitionBy('trans_num')
# df.distinct(col("trans_num")).count()

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import *

customer = df.select ("ssn", "first", "last", "cc_num", "gender", "job", "dob","acct_num")
customer = customer.dropDuplicates(["acct_num","cc_num","ssn"])

window = Window.orderBy(col('ssn'))
customer = customer.select("*").withColumn("cust_id", row_number().over(window))

# COMMAND ----------

display(customer)

# COMMAND ----------

address = df.select ("street", "zip", "lat", "long", "state", "city", "city_pop")

address = address.dropDuplicates(["street","zip"])

window = Window.orderBy(col('zip')).orderBy(col('street'))

address = address.select("*").withColumn("addr_id", row_number().over(window))

# COMMAND ----------

display(address)

# COMMAND ----------

merchant = df.select("merchant", "category", "merch_lat", "merch_long")

merchant = merchant.dropDuplicates(["merchant", "category"])

window = Window.orderBy(col('merchant')).orderBy(col('category'))

merchant = merchant.select("*").withColumn("merch_id", row_number().over(window))

# COMMAND ----------

display(merchant)

# COMMAND ----------

transaction = df

# COMMAND ----------

customer.createOrReplaceTempView("customer")
merchant.createOrReplaceTempView("merchant")
address.createOrReplaceTempView("address")
transaction.createOrReplaceTempView("dwh_transaction")

# COMMAND ----------

beginDate = '2018-01-01'
endDate = '2023-12-31'

(
  spark.sql(f"select explode(sequence(to_date('{beginDate}'), to_date('{endDate}'), interval 1 day)) as calendarDate")
    .createOrReplaceTempView('dates')
)

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from dates

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE new_table2
# MAGIC   AS (
# MAGIC select 
# MAGIC   year(calendarDate) * 10000 + month(calendarDate) * 100 + day(calendarDate) as date_id,
# MAGIC   CalendarDate,
# MAGIC   year(calendarDate) AS CalendarYear,
# MAGIC   date_format(calendarDate, 'MMMM') as CalendarMonth,
# MAGIC   month(calendarDate) as MonthOfYear,
# MAGIC   date_format(calendarDate, 'EEEE') as CalendarDay,
# MAGIC   dayofweek(calendarDate) AS DayOfWeek,
# MAGIC   weekday(calendarDate) + 1 as DayOfWeekStartMonday,
# MAGIC   case
# MAGIC     when weekday(calendarDate) < 5 then 'Y'
# MAGIC     else 'N'
# MAGIC   end as IsWeekDay,
# MAGIC   dayofmonth(calendarDate) as DayOfMonth,
# MAGIC   case
# MAGIC     when calendarDate = last_day(calendarDate) then 'Y'
# MAGIC     else 'N'
# MAGIC   end as IsLastDayOfMonth,
# MAGIC   dayofyear(calendarDate) as DayOfYear,
# MAGIC   weekofyear(calendarDate) as WeekOfYearIso,
# MAGIC   quarter(calendarDate) as QuarterOfYear
# MAGIC 
# MAGIC from
# MAGIC   dates
# MAGIC order by
# MAGIC   calendarDate
# MAGIC )

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from new_table2 limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC create table trans as(
# MAGIC select t.trans_num as trans_id, d.date_id, c.cust_id, m.merch_id, a.addr_id, t.amt, t.is_fraud  from dwh_transaction t
# MAGIC left join customer c
# MAGIC on (c.ssn = t.ssn and c.cc_num = t.cc_num and c.acct_num = t.acct_num)
# MAGIC left join merchant m
# MAGIC on (m.merchant = t.merchant and m.category = t.category )
# MAGIC left join address a
# MAGIC on (a.street = t.street and a.zip = t.zip )
# MAGIC left join new_table2 d
# MAGIC on (d.CalendarDate = t.trans_date)
# MAGIC )

# COMMAND ----------

trans = spark.sql("select * from trans")
display(trans)

# COMMAND ----------

cc = spark.sql("select count( distinct merch_id) from trans")
display(cc)

# COMMAND ----------

dates = spark.sql("select * from new_table2")

# COMMAND ----------

jdbcHostname = "testnev.database.windows.net"
jdbcDatabase = "transactioncard"
jdbcPort = 1433
jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
connectionProperties = {
"user" : "tunglv",
"password" : "Tung13032000",
"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

# COMMAND ----------

m = spark.sql("select count(*) from trans")
trans = spark.sql("select * from trans")


# COMMAND ----------

display(trans)

# COMMAND ----------

trans.write.jdbc(url=jdbcUrl, table="dbo.transactions", mode = "append",properties=connectionProperties)

# COMMAND ----------

customer.select("ssn", "first", "last", "cc_num", "gender", "job", "dob","acct_num").write.jdbc(url=jdbcUrl, table="dbo.customers", mode = "append",properties=connectionProperties)

# COMMAND ----------

display(customer)

# COMMAND ----------

merchant.select("merchant","category","merch_lat","merch_long").write.jdbc(url=jdbcUrl, table="dbo.merchants", mode = "append",properties=connectionProperties)

# COMMAND ----------


address.select("street","zip","lat","long","state","city","city_pop").write.jdbc(url=jdbcUrl, table="dbo.addresses", mode = "append",properties=connectionProperties)

# COMMAND ----------

dates.write.jdbc(url=jdbcUrl, table="dwh.dates", mode = "append",properties=connectionProperties)